#!/system/bin/sh


# This install-recovery.sh is installed here to start the
# seSuperuser su binary in daemon mode

/system/xbin/su --daemon &

