

# Below command is here to start the seSuperuser su binary in daemon mode

/system/xbin/su --daemon &

